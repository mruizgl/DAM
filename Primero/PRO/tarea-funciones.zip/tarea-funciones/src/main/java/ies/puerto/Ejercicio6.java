package ies.puerto;

public class Ejercicio6 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}