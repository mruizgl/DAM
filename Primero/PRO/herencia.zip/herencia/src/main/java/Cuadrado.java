public class Cuadrado {
}
