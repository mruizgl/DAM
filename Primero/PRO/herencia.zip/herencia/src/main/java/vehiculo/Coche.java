package vehiculo;

import java.util.Scanner;

public class Coche extends Vehiculo{

    public Coche(String marca, String modelo, double precio) {
        super(marca, modelo, precio);
    }


}
