package vehiculo;

public class Conductor {

}
