package utilidades;

public class UtilidadesCal {
    public int suma (int numero1, int numero2) {
        return numero1 + numero2;
    }
    public int resta (int numero1, int numero2) {
        return numero1 - numero2;
    }

    public double multiplicacion (double numero1, double numero2) {
        return numero1 * numero2;
    }

    public double division (double numero1, double numero2) {
        return numero1 / numero2;
    }
}
