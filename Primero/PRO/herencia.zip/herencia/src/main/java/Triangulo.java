public class Triangulo {
}
