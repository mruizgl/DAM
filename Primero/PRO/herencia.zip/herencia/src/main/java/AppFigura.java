package app;

public class AppFigura {
}
