public class Figura {
}
