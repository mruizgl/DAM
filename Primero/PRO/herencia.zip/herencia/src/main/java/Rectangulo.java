public class Rectangulo {
}
