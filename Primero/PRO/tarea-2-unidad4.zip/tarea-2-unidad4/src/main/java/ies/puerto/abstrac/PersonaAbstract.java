package ies.puerto.abstrac;

public abstract class PersonaAbstract {
    private String nombre;
    private String fechaNacimiento;

    public abstract int anios(String fechaNacimiento);
}
