package ies.puerto.interfaz;

public interface IInstrumentoMusical {
    public String tocarNota(String nota);
    public String afinar ();

}
