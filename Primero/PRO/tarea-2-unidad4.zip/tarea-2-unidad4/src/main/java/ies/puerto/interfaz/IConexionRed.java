package ies.puerto.interfaz;

public interface IConexionRed {
    public String conectar();
}
