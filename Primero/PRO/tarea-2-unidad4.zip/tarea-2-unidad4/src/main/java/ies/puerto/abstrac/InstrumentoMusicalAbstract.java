package ies.puerto.abstrac;

public abstract class InstrumentoMusicalAbstract {
    public abstract String tocarNota(String nota);
    public abstract String afinar();

}
