package ies.puerto.abstrac;

public abstract class ConexionAbstract {
    public String conectar() {
        return "Conectando";
    }
}
