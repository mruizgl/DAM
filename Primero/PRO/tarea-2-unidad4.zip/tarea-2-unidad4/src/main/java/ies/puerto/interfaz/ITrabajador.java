package ies.puerto.interfaz;

public interface ITrabajador {
}
