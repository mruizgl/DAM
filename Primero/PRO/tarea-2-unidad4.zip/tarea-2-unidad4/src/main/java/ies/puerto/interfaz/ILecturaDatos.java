package ies.puerto.interfaz;

public interface ILecturaDatos {
    public String lectura();
    public String apertura();
    public String cierre();
}
