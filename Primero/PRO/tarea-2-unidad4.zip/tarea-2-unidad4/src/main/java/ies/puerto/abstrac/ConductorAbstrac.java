package ies.puerto.abstrac;

public abstract class ConductorAbstrac {
    public abstract String tocarNota();
    public abstract String afinar();
    public abstract String cambiarCuerdas();
}
