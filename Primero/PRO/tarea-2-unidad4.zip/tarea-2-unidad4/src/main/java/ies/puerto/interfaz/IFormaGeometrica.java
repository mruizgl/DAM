package ies.puerto.interfaz;

public interface IFormaGeometrica {
    public float calcularArea();
}
