package ies.puerto.abstrac;

public abstract class LecturaDatosAbstract {
    public abstract String lectura();
    public abstract String apertura();
    public abstract String cierre();

}
