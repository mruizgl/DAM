package ies.puerto.interfaz;

public interface IConductor {
    public String arrancar();
    public String detener();
}
