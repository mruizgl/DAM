package ies.puerto.interfaz;

/**
 * Definimos interfaz de Reproductor
 */
public interface IReproductor {
    //reproducir y detener

    public String reproducir();
    public String detener();
}
