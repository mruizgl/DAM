package ies.puerto;

public class Ejercicio2 {

    public int ordenarNumerosEnteros () {
        int numero = 0;

        return numero;
    }
}
