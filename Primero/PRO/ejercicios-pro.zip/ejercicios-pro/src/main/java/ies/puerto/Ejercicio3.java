package ies.puerto;

public class Ejercicio3 {

    /**
     * Funcion que indica el resultado del alumno
     * @param nota del alumno
     * @param resultado del alumno
     * @return devuelve resultado
     */
    public String clasificacionEstudiantes(double nota, String resultado) {


        if (nota > 0 && nota <4.99) {
            resultado = "Suspendido";
        }
        if (nota >5 && nota < 5.99) {
            resultado = "Aprobado";
        }
        if (nota > 6 && nota < 6.99) {
            resultado = "Bien";
        }
        if (nota > 7 && nota < 8.99) {
            resultado = "Notable";
        }
        if (nota > 9 && nota < 10) {
            resultado = "Sobresaliente";
        }
        return " El alumno tiene un "+ resultado;
    }

}
