package ies.puerto;

/**
 * @author Melissa
 */
public class Ejercicio4 {
    private String titular;
    private double Saldo;

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return Saldo;
    }

    public void setSaldo(double saldo) {
        Saldo = saldo;
    }


    Ejercicio4 cuentaBanco;

    /**
     * Constructor por defecto
     */
    public Ejercicio4() {};

    /**
     * Constructor con todos los parametros
     * @param titular de la cuenta del banco
     * @param saldo de la cuenta del banco
     */
    public Ejercicio4(String titular, double saldo) {
        this.titular = titular;
        Saldo = saldo;
    }

    /**
     * Funcion que permite imprimir información del usuario
     * @param titular de la cuenta del banco
     * @return devuelve resultado
     */
    public String imprimirInformacion (String titular, double saldo) {
        return "El usuario es: " + titular + " y su saldo actual es de: " + saldo;
    }

    /**
     * Funcion para depositar saldo en la cuenta bancaria
     * @param saldo de la cuenta bancaria
     * @param nuevoSaldo de la cuenta bancaria
     * @return devuelve resultado
     */
    public int depositarSaldo (int saldo, int nuevoSaldo) {
        saldo = nuevoSaldo;
        return nuevoSaldo;
    }

    /**
     * FUncion para retirar efectivo
     * @param saldo saldo de la cuenta
     * @param monto a retirar
     * @return devuelve el nuevo saldo de la cuenta
     */
    public int sacarDinero (int saldo, int monto) {
        monto = 20;
        return saldo - monto;
    }


}
