package ies.puerto.interfaces;

public interface ISaludable {
    
    public int caducidad();
    public boolean estaCadudado();
}
