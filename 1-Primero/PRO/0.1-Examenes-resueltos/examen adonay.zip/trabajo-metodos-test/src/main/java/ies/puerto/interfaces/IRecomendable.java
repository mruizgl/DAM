package ies.puerto.interfaces;

public interface IRecomendable {

    public boolean recomendar();
    public int popularidad();
}
