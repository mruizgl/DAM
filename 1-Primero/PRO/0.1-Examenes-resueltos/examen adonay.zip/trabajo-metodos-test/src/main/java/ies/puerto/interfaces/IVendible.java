package ies.puerto.interfaces;

public interface IVendible {
    

    public float precioMaximo();
    public int cantidadDisponible();
}
