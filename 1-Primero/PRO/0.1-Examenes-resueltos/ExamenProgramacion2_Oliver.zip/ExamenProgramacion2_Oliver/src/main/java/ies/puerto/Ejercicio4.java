package ies.puerto;

import java.util.Scanner;

public class Ejercicio4 {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame el numero de filas para el dibujo: ");
        int filas=sc.nextInt();
        if(filas<4){

            throw new Exception("No se puede poner menos de 4 columnas");
        }








    }






}
