public class Ejercicio2Test {
}
