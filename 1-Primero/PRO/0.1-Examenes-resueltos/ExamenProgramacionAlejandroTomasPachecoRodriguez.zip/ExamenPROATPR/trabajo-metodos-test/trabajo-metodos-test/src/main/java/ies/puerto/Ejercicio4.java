package ies.puerto;

public class Ejercicio4 {
    puerta[] puertas = new puerta[5];

    /**
     * Constructor por defecto
     */
    public Ejercicio4() {
        for (int i = 0; i < puertas.length; i++) {
            puertas[i].setNumeroPuerta(i + 1);
        }
    }

    /**
     * Funcion que abre una puerta
     *
     * @param numeroPuerta
     */
    public void abrirPuerta(int numeroPuerta) {
        int i = 0;
        while (i < puertas.length) {
            if (numeroPuerta == puertas[i].getNumeroPuerta()) {
                puertas[i].setEstado("Abierta");
            }
            i++;
        }
    }

    /**
     * Funcion que cambia el estado de la puerta
     *
     * @param numeroPuerta
     */
    public void cambiarEstadoPuerta(int numeroPuerta) {
        int i = 0;
        while (i < puertas.length) {
            if (numeroPuerta == puertas[i].getNumeroPuerta()) {
                switch (puertas[i].getEstado()) {
                    case "Abierta":
                        puertas[i].setEstado("Cerrada");
                        break;
                    case "Cerrada":
                        puertas[i].setEstado("Abierta");
                        break;
                }
            }
            i++;
        }
    }

    /**
     * Funcion que cierra una puerta
     *
     * @param numeroPuerta
     */
    public void cerrarPuerta(int numeroPuerta) {
        int i = 0;
        while (i < puertas.length) {
            if (numeroPuerta == puertas[i].getNumeroPuerta()) {
                puertas[i].setEstado("Cerrada");
            }
            i++;
        }
    }

    /**
     * Funcion que muestra el estado de las 5 puertas
     */
    public void mostrarEstadoPuertas() {
        for (int i = 0; i < puertas.length; i++) {
            System.out.println("Puerta " + i + ":" + puertas[i].getEstado());
        }
    }
}
class puerta {
    private int numeroPuerta;
    private String estado;

    /**
     * Constructor por defecto
     */
    public puerta () {
        this.estado = "Cerrado";
    }

    /**
     * Constructor con el numero de puerta
     * @param numeroPuerta
     */
    public puerta(int numeroPuerta) {
        this.numeroPuerta = numeroPuerta;
    }

    /**
     * Constructor con el estado de la puerta
     * @param estado de la puerta
     */
    public puerta (String estado) {
        this.estado = estado;
    }

    /**
     * Constructor con el numero y estado de la puerta
     * @param numeroPuerta
     * @param estado de la puerta
     */
    public puerta(int numeroPuerta, String estado) {
        this.numeroPuerta = numeroPuerta;
        this.estado = estado;
    }

    public int getNumeroPuerta() {
        return numeroPuerta;
    }

    public void setNumeroPuerta(int numeroPuerta) {
        this.numeroPuerta = numeroPuerta;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}