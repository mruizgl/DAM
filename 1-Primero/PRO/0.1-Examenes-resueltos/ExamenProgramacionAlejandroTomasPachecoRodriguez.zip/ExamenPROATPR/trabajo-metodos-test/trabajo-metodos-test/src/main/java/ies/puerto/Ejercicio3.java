package ies.puerto;

public class Ejercicio3 {
    public static void main (String[] args) {
        String[][] Domino = crearTablaFichas();
        mostrarTablaFichas(Domino);
        extraerFicha(Domino, "Ficha 1");
        mostrarTablaFichas(Domino);
    }

    /**
     * Metodo que crea una nueva tabla de fichas de domino
     * @return tabla de fichas
     */
    public static String[][] crearTablaFichas () {
        String[][] tablaFichas = new String[8][7];
        int i = 0;
        while (i < tablaFichas.length) {
            int j = i;
            while (j < tablaFichas[i].length) {
                if (i == 0)
                    tablaFichas[i][j] = "Ficha " + (j+1);
                else
                    tablaFichas[i][j-1] = i-1 + ":" + (j-1);
                j++;
                if (i !=0 && j == tablaFichas.length-1) {
                    tablaFichas[i][j-1] = i-1 + ":" + (j-1);
                }
            }
            i++;
            j--;
            if (i == tablaFichas.length-1 && j == tablaFichas[0].length-1) {
                tablaFichas[i][j] = i-1 + ":" + (j);
            }
        }
        return tablaFichas;
    }

    /**
     * Funcion que muestra la tabla de fichas
     * @param tablaFichas
     */
    public static void mostrarTablaFichas (String[][] tablaFichas) {
        for (int i = 0; i < tablaFichas.length; i++){
            for (int j = 0; j < tablaFichas[i].length; j++){
                System.out.print(tablaFichas[i][j] + "      ");
            }
            System.out.println();
        }
    }

    public static void extraerFicha (String[][] tablaFichas, String fichaExtraer) {
        int i = 0;
        boolean extraido = false;
        while (i < tablaFichas.length) {
            int j = 0;
            while ( j < tablaFichas[i].length) {
                if (tablaFichas[i][j] == fichaExtraer) {
                    tablaFichas[i][j] = "X:X";
                    extraido = true;
                    break;
                }
                j++;
            }
            if (extraido)
                break;
            i++;
        }
    }
}