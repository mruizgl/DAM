package ies.puerto;

import org.junit.jupiter.api.Test;

public class Ejercicio3Test {

    @Test
    public void testOK() {

    }
}
