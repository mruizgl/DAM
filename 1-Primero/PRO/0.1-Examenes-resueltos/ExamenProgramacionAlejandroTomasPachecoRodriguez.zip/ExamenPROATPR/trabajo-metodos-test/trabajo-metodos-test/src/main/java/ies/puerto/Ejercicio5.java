package ies.puerto;

import java.util.Scanner;

public class Ejercicio5 {
    public static void main(String[] args) {
        double numero;
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduzca un numero para ver el mes correspondiente a este");
        numero = lectura.nextDouble();
        System.out.println("El mes correspondiente a "+ numero+ " con IfElse es: " + mesIfSele(numero));
        System.out.println("El mes correspondiente a "+ numero+ " con Switch es: " +mesSwitch(numero));
    }

    /**
     * Metodo que calcula el mes segun un numero con IfElses
     * @param numero del mes
     * @return nombre del mes
     */
    public static String mesIfSele (double numero) {
        int numeroMes = (int) numero;

        if (numeroMes == 1) {
            return "Enero";
        } else if (numeroMes == 2) {
            return "Febrero";
        } else if (numeroMes == 3) {
            return "Marzo";
        } else if (numeroMes == 4) {
            return "Abril";
        } else if (numeroMes == 5) {
            return "Mayo";
        } else if (numeroMes == 6) {
            return "Junio";
        } else if (numeroMes == 7) {
            return "Julio";
        } else if (numeroMes == 8) {
            return "Agosto";
        } else if (numeroMes == 9) {
            return "Septiembre";
        } else if (numeroMes == 10) {
            return "Octubre";
        } else if (numeroMes == 11) {
            return "Noviembre";
        } else if (numeroMes == 12) {
            return "Diciembre";
        } else {
            return "No existe un mes correspondiente a " + numero;
        }
    }

    /**
     * Metodo que calcula el mes segun un numero con un Switch
     * @param numero del mes
     * @return nombre del mes
     */
    public static String mesSwitch(double numero) {
        int numeroMes = (int) numero;

        switch (numeroMes) {
            case 1:
                return "Enero";
            case 2:
                return "Febrero";
            case 3:
                return "Marzo";
            case 4:
                return "Abril";
            case 5:
                return "Mayo";
            case 6:
                return "Junio";
            case 7:
                return "Julio";
            case 8:
                return "Agosto";
            case 9:
                return "Septiembre";
            case 10:
                return "Octubre";
            case 11:
                return "Noviembre";
            case 12:
                return "Diciembre";
            default:
                return "No existe un mes correspondiente a " + numero;
        }
    }
}