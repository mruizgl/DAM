package ies.puerto;

/**
 * Clase que representa la informacion de un Estudiante
 * @author Alejandro Tomas Pacheco Rodriguez
 */
public class Ejercicio2 {
    private String nombre;
    private int edad;
    private double peso;
    private double altura;


    /**
     * Constructor por defecto
     */
    public Ejercicio2 () {}

    /**
     * Constructor con la variable nombre
     * @param nombre del estudiante
     */
    public Ejercicio2(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Constructor  con la variable edad
     * @param edad del estudiante
     */
    public Ejercicio2(int edad) {
        this.edad = edad;
    }

    /**
     * Constructor con la variable peso del estudiante
     * @param peso del estudiante
     */
    public Ejercicio2(double peso) {
        this.peso = peso;
    }

    /**
     * Constructor con la variable altura
     * @param altura del estudiante
     */
    public Ejercicio2 (float altura) {
        this.altura = altura;
    }

    /**
     * Constructor con las variables nombre y edad del estudiante
     * @param nombre del estudiante
     * @param edad del estudiante
     */
    public Ejercicio2(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    /**
     * Constructor con las variables nombre y peso del estudiante
     * @param nombre del estudiante
     * @param peso del estudiante
     */
    public Ejercicio2(String nombre, double peso) {
        this.nombre = nombre;
        this.peso = peso;
    }

    /**
     * Constructor con las variables nombre y altura del estudiante
     * @param nombre del estudiante
     * @param altura del estudiante
     */
    public Ejercicio2(String nombre, float altura) {
        this.nombre = nombre;
        this.altura = altura;
    }

    /**
     * Constructor con las variables edad y peso del estudiante
     * @param edad del estudiante
     * @param peso del estudiante
     */
    public Ejercicio2(int edad, double peso) {
        this.edad = edad;
        this.peso = peso;
    }

    /**
     * Constructor con las variables edad y altura del estudiante
     * @param edad del estudiante
     * @param altura del estudiante
     */
    public Ejercicio2(int edad, float altura) {
        this.edad = edad;
        this.altura = altura;
    }

    /**
     * Constructor con las variables nombre, edad y peso del estudiante
     * @param nombre del estudiante
     * @param edad del estudiante
     * @param peso del estudiante
     */
    public Ejercicio2(String nombre, int edad, double peso) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
    }

    /**
     * Constructor con las variables nombre, edad, y altura del estudiante
     * @param nombre del estudiante
     * @param edad del estudiante
     * @param altura del estudiante
     */
    public Ejercicio2(String nombre, int edad, float altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
    }

    /**
     * Constructor con las variables nombre, peso, y altura del estudiante
     * @param nombre del estudiante
     * @param peso del estudiante
     * @param altura del estudiante
     */
    public Ejercicio2(String nombre, double peso, double altura) {
        this.nombre = nombre;
        this.peso = peso;
        this.altura = altura;
    }

    /**
     * Constructor con las variables edad, peso y altura del estudiante
     * @param edad del estudiante
     * @param peso del estudiante
     * @param altura del estudiante
     */
    public Ejercicio2(int edad, double peso, double altura) {
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
    }

    /**
     * Constructor con las variables nombre, edad, peso y altura del estudiante
     * @param nombre del estudiante
     * @param edad del estudianrte
     * @param peso del estudiante
     * @param altura del estudiante
     */
    public Ejercicio2(String nombre, int edad, double peso, double altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * Metodo que calcula el IMC del estudiante
     * @return IMC del estudiante
     */
    public double calcularIMC () {
        return (this.peso / (this.altura * this.altura));
    }

    /**
     * Funcion que imprime la informacion del estudiante incluido el imc
     */
    public void mostrarInformacion () {
        System.out.println( "Nombre: " + nombre + ", edad: " + edad + ", peso: " + peso + ", altura: " + altura + ", IMC: " + calcularIMC());
    }
}