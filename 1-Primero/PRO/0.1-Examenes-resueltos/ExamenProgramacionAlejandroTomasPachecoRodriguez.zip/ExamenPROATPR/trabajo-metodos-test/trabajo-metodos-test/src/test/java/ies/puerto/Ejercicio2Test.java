package ies.puerto;

import org.junit.jupiter.api.Test;

public class Ejercicio2Test {

    @Test
    public void testOK() {

    }
}
