<div align="justify">

# Objetivo del proyecto

Este proyecto mavenn tiene como objetivo ayudar a comprender al alumno el úso de métodos en java, y la documentación de los módulos.

## Comandos maven a utilizar

- Limpieza y compilación del proyecto

    ```console
    mvn clean install
    ```

- Generación de la documentación del proyecto (javadoc)

    ```console
    mvn javadoc:javadoc 
    ```
- Ejecución de tes

    ```console
    mvn clean test 
    ``` 
 
</div>