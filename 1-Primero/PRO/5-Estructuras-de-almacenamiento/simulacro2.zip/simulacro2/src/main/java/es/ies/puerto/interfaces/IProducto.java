package es.ies.puerto.interfaces;

public interface IProducto {

    public float precioMaximo();

    public int cantidadDisponible();


}
