package es.ies.puerto.interfaces;

public interface ISaludable {
    public int calcularCaducidad();
    public boolean caducado();
}
