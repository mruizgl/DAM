package es.ies.puerto.interfaces;

public interface IRecomendable {
    public boolean recomendarProducto();
    public int calcularPopularidad();

}
