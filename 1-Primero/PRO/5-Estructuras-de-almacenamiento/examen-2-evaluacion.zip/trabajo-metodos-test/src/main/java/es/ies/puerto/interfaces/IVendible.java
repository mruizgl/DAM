package es.ies.puerto.interfaces;

public interface IVendible {
    public float calcularPrecioMaximo();
    public int cantidadDisponible();
}
