package ies.puerto.interfaces;

public class IVehiculo {
    public static int velocidadMaxima() {

        return 0;
    }
}
